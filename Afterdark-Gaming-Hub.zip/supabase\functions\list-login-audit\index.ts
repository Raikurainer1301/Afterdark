import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("SITE_ORIGIN") ?? "https://YOUR-SITE-DOMAIN.example",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Vary": "Origin",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
});

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "GET") return json({ error: "Method not allowed" }, 405);

  const token = (request.headers.get("Authorization") ?? "").match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return json({ error: "Authentication required" }, 401);
  const url = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  const administrators = (Deno.env.get("AUDIT_ADMIN_USER_IDS") ?? "").split(",").map((id) => id.trim()).filter(Boolean);
  if (!url || !anonKey || !serviceKey || !administrators.length) return json({ error: "Audit service is not configured" }, 503);

  const authClient = createClient(url, anonKey, { auth: { persistSession: false } });
  const { data: auth, error: authError } = await authClient.auth.getUser(token);
  if (authError || !auth.user) return json({ error: "Invalid session" }, 401);
  if (!administrators.includes(auth.user.id)) return json({ error: "Administrator access required" }, 403);

  const adminClient = createClient(url, serviceKey, { auth: { persistSession: false } });
  const cutoff = new Date(Date.now() - 30 * 86400000).toISOString();
  await adminClient.from("afterdark_login_audit").delete().lt("logged_at", cutoff);
  const { data, error } = await adminClient.from("afterdark_login_audit")
    .select("id,user_id,ip_address,logged_at")
    .gte("logged_at", cutoff)
    .order("logged_at", { ascending: false })
    .limit(200);
  if (error) return json({ error: "Could not load audit events" }, 500);
  return json({ events: data ?? [] });
});
