// Configure with your Supabase project values. The anon key is intended for browser use; protect every table with RLS.
window.AFTERDARK_SUPABASE_CONFIG = {
  url: 'https://YOUR-PROJECT.supabase.co',
  anonKey: 'YOUR_SUPABASE_ANON_KEY'
};
