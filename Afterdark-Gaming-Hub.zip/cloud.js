// Optional Supabase persistence. User records never fall back to localStorage.
(() => {
  const config = window.AFTERDARK_SUPABASE_CONFIG || {};
  const configured = config.url && config.anonKey && !config.url.includes('YOUR-PROJECT') && !config.anonKey.includes('YOUR_SUPABASE');
  let client = null;
  let session = null;
  let saveTimer = null;
  let queuedPayload = null;
  const status = document.querySelector('#cloud-status');
  const button = document.querySelector('#cloud-auth-button');
  const setStatus = message => { if (status) status.textContent = message; };
  const configuredMessage = 'Cloud storage is not configured yet. Add your Supabase project URL and anon key in cloud-config.js, then run the SQL in supabase/schema.sql.';
  const redraw = () => {
    updateHeader(); renderHome(); renderFinder(); renderBoard(); renderProfile();
  };

  if (!configured || !window.supabase?.createClient) {
    setStatus('CLOUD NOT CONFIGURED');
    window.afterdarkCloudSave = () => {};
    document.addEventListener('click', event => {
      if (event.target.closest('[data-action="cloud-auth"]')) {
        modal('Connect cloud storage', `<p>${configuredMessage}</p><p>Once configured, profiles, favorites, and manually entered stats are stored in your Supabase database. Guest edits are memory-only and disappear when this tab closes.</p>`);
      }
    });
    return;
  }

  client = window.supabase.createClient(config.url, config.anonKey, {
    auth: { persistSession: true, autoRefreshToken: true, storage: window.sessionStorage }
  });

  window.afterdarkCloudSave = payload => {
    if (!session) { setStatus('SIGN IN TO SAVE TO CLOUD'); return; }
    queuedPayload = JSON.parse(JSON.stringify(payload));
    setStatus('SYNC QUEUED…');
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      const currentSession = session;
      const snapshot = queuedPayload;
      if (!currentSession || !snapshot) return;
      setStatus('SYNCING…');
      const { error } = await client.from('afterdark_user_data').upsert({
        user_id: currentSession.user.id,
        payload: snapshot,
        updated_at: new Date().toISOString()
      }, { onConflict: 'user_id' });
      setStatus(error ? 'CLOUD SAVE FAILED' : 'CLOUD SYNCED');
      if (error) toast(`Cloud save failed: ${esc(error.message)}`);
    }, 250);
  };

  const showAuth = () => {
    if (!session) {
      modal('Sign in or create account', `<p>Your profile, favorites, and stats will sync to your Supabase project. Use a unique password; passwords are sent directly to Supabase Auth and are never stored by this site.</p><form id="cloud-auth-form" class="formstack"><label class="field">EMAIL<input class="input" type="email" name="email" autocomplete="email" required maxlength="254"></label><label class="field">PASSWORD<input class="input" type="password" name="password" autocomplete="current-password" required minlength="8" maxlength="128"></label><label class="audit-consent"><input type="checkbox" name="auditConsent" required><span>I understand that successful sign-ins record my IP address and time for security. Only authorized administrators can view this information, and it is retained for up to 30 days.</span></label><div class="modal-actions"><button class="red" type="submit" name="mode" value="signin">Sign in</button><button class="ghost" type="submit" name="mode" value="signup">Create account</button></div><p id="auth-message" class="note" aria-live="polite"></p></form>`);
    } else {
      modal('Cloud account', `<p>Signed in as <b>${String(session.user.email).replace(/[&<>"']/g, '')}</b>. Your app data is stored in your Supabase project.</p><button class="red" id="cloud-signout">Sign out</button>`);
    }
  };

  document.addEventListener('click', event => {
    if (event.target.closest('[data-action="cloud-auth"]')) showAuth();
    if (event.target.closest('#cloud-signout')) client.auth.signOut().then(({error}) => {
      if (error) toast(error.message); else { session = null; data = { favs: [], stats: [], recent: [], vibes: [] }; window.afterdarkCloudSnapshot = data; setStatus('SIGNED OUT'); button.textContent = 'Sign in / Create account'; $('#modal').close(); redraw(); }
    });
  });

  document.querySelector('#modal').addEventListener('submit', async event => {
    if (event.target.id !== 'cloud-auth-form') return;
    event.preventDefault();
    const form = new FormData(event.target);
    const email = String(form.get('email')).trim().toLowerCase();
    const password = String(form.get('password'));
    const mode = event.submitter?.value || 'signin';
    const message = document.querySelector('#auth-message');
    if (form.get('auditConsent') !== 'on') { message.textContent = 'Please acknowledge the security audit notice to continue.'; return; }
    const submitButtons = [...event.target.querySelectorAll('button[type="submit"]')];
    submitButtons.forEach(item => item.disabled = true);
    message.textContent = mode === 'signup' ? 'Creating your account…' : 'Signing in…';
    const result = mode === 'signup'
      ? await client.auth.signUp({ email, password })
      : await client.auth.signInWithPassword({ email, password });
    submitButtons.forEach(item => item.disabled = false);
    if (result.error) { message.textContent = result.error.message; return; }
    if (mode === 'signup' && !result.data.session) {
      message.textContent = 'Check your email to confirm the account, then return here and sign in.';
      return;
    }
    session = result.data.session;
    if (session) {
      const { error: auditError } = await client.functions.invoke('record-login', { method: 'POST', body: { acknowledged: true } });
      if (auditError) toast('Signed in, but this login could not be added to the security audit.');
    }
    await loadCloudData();
    await checkAdminAccess();
    $('#modal').close(); toast('Cloud account connected');
  });

  async function loadCloudData() {
    if (!session) return;
    setStatus('LOADING CLOUD DATA…');
    const { data: row, error } = await client.from('afterdark_user_data').select('payload').eq('user_id', session.user.id).maybeSingle();
    if (error) { setStatus('CLOUD LOAD FAILED'); toast(`Cloud load failed: ${error.message}`); return; }
    const defaults = { favs: [], stats: [], recent: [], vibes: [] };
    const remote = row?.payload && typeof row.payload === 'object' ? row.payload : {};
    data = { ...defaults, ...remote };
    window.afterdarkCloudSnapshot = data;
    setStatus('CLOUD SYNCED');
    button.textContent = 'Cloud account';
    redraw();
    if (!row) window.afterdarkCloudSave(data);
  }

  const checkAdminAccess = async () => {
    if (!session) { setDeveloperAccess(false); return; }
    await loadAudit();
  };

  document.addEventListener('click', event => {
    if (event.target.closest('[data-action="refresh-audit"]')) loadAudit();
    if (event.target.closest('[data-view="developer"]')) loadAudit();
  });

  client.auth.getSession().then(({ data: authData, error }) => {
    if (error) { setStatus('AUTH CHECK FAILED'); return; }
    session = authData.session;
    if (session) { loadCloudData(); checkAdminAccess(); } else setStatus('SIGN IN TO ENABLE CLOUD SYNC');
  });
  client.auth.onAuthStateChange((eventName, nextSession) => {
    session = nextSession;
    if (session) { loadCloudData(); if (eventName === 'SIGNED_IN') checkAdminAccess(); }
    else { setDeveloperAccess(false); if (document.querySelector('.view.active')?.id === 'developer') go('home'); setStatus('SIGN IN TO ENABLE CLOUD SYNC'); if (button) button.textContent = 'Sign in / Create account'; }
  });
  const developerNav = document.querySelector('#developer-nav');
  const auditBody = document.querySelector('#audit-body');
  const auditMessage = document.querySelector('#audit-message');
  const setDeveloperAccess = allowed => { if (developerNav) developerNav.hidden = !allowed; };
  const loadAudit = async () => {
    if (!session || !auditBody) return;
    auditMessage.textContent = 'Checking administrator access…';
    const { data, error } = await client.functions.invoke('list-login-audit', { method: 'GET' });
    if (error) { setDeveloperAccess(false); auditMessage.textContent = error.context?.status === 403 ? 'This account is not on the developer allow-list.' : 'Audit service unavailable. Deploy and configure its Edge Function.'; return; }
    setDeveloperAccess(true);
    auditBody.replaceChildren();
    if (!data.events?.length) { auditBody.innerHTML = '<tr><td colspan="3" class="empty">No sign-ins recorded in the last 30 days.</td></tr>'; }
    else for (const event of data.events) {
      const row = document.createElement('tr');
      for (const value of [new Date(event.logged_at).toLocaleString() + ' UTC', event.user_id, event.ip_address]) {
        const cell = document.createElement('td'); cell.textContent = value; row.append(cell);
      }
      auditBody.append(row);
    }
    auditMessage.textContent = `Showing ${data.events.length} most recent event(s); events older than 30 days are expired.`;
  };
})();
