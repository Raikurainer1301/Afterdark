# Afterdark Gaming Hub

A responsive, static gaming hub with game discovery, sample leaderboards, browser utilities, task-specific gaming assistants, and optional Supabase cloud accounts.

## Run locally

For a quick static preview, open `index.html` in a modern browser. To test Supabase sign-in, serve the folder over HTTP (for example with VS Code Live Server) and add that local URL to the Supabase Auth redirect allow-list. No build step or package installation is required.

## Features

- Game finder with genre, group size, platform, estimated budget, download-size, free-to-play, and squad-vibe filters.
- Around 30 catalog entries, with official Steam store links where a Steam listing exists. Minecraft and Fortnite link to their official non-Steam stores.
- Game detail dialogs with descriptions, platform/player information, estimated catalog data, and system requirements when verified from Steam listing information. Other games link to Steam's current requirements.
- Favorites, recent views, profile preferences, and manual stats saved to Supabase when configured and signed in. Guest edits are memory-only and do not persist.
- Fictional, clearly marked leaderboard demo data and unverified manual stat entries (cloud-saved when signed in).
- Calculators, group randomizers, local session timer, scoreboard, and rule-based gaming assistants. These are not connected to an AI model or live gaming APIs.

Prices and download sizes are planning estimates and can change. Verify current prices, availability, platform support, and system requirements on the official store listing.

## Publish on the web

The site is static and can be hosted on Vercel, Netlify, or GitHub Pages. A Vercel static-site configuration is included in `vercel.json`.

### Vercel quick start

1. Push this folder to a GitHub repository.
2. Import the repository in Vercel and choose the **Other** framework preset.
3. Leave the build command empty and set the output directory to `.`.
4. Deploy. Vercel will provide a temporary `*.vercel.app` address.
5. To use a custom domain, first register and pay for a domain through a domain registrar. In Vercel, open the project’s **Settings → Domains**, enter the domain you own, and apply the exact DNS records Vercel displays at your registrar. DNS values vary by project and provider; do not copy generic records from this example.
6. Wait for DNS verification and HTTPS provisioning, then test the custom domain.

A domain must be selected, registered, and controlled by you. This project cannot register or claim a domain on your behalf. Until you choose one, use the hosting provider's free preview domain.

## Important deployment notes

- Cloud storage requires your own Supabase project. Create a project, run `supabase/schema.sql` in its SQL Editor, then replace the URL and anon key placeholders in `cloud-config.js`. The anon key is public browser configuration; never add a service-role key to this site. Row-level security policies in the schema restrict rows to their authenticated owner.
- Enable email/password auth in Supabase. Configure the Supabase Auth site URL and redirect URLs for both local testing and your deployed/custom domain. Email confirmation can be enabled in the Supabase project.
- App data is written to the remote Supabase table, not localStorage. The Supabase authentication token is kept in sessionStorage for the current browser tab. Without backend configuration, guest changes are memory-only and disappear when the tab closes.
- Optional login security audit: the sign-in dialog discloses collection and requires acknowledgment. After successful sign-in, the server-side `record-login` Edge Function records the source IP and timestamp. The `list-login-audit` function checks the authenticated user ID against the server-only `AUDIT_ADMIN_USER_IDS` allow-list. IP log table has no browser-role grants and the scheduled SQL cleanup deletes events older than 30 days. IP addresses can indicate a network's approximate region, not a person's precise location.
- To enable that feature, deploy `supabase/functions/record-login` and `supabase/functions/list-login-audit`, set Edge Function secrets `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `AUDIT_ADMIN_USER_IDS` (comma-separated auth user UUIDs), and `SITE_ORIGIN` (your exact HTTPS website origin). Never place the service-role key in the browser. Run `supabase/schema.sql` to create the restricted audit table and daily retention job. The developer menu appears only after the server confirms the current account is an allowed admin; the API enforces the same authorization independently.
- Get the admin UUID from Supabase Authentication → Users after the admin account is created. Deploy the functions with the Supabase CLI and set the allow-list and exact site origin in Edge Function secrets. The scheduled cleanup requires `pg_cron` to be available in the Supabase project; confirm the named job exists in the Cron dashboard after running the schema.
- The AI specialist panels are local rule-based helpers, not generative AI. Connecting a real model requires a backend endpoint and secret management; do not put an API key in browser JavaScript.
- Leaderboard players are fictional. No Steam account data or live game statistics are fetched.
