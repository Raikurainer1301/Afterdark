-- Run this in Supabase SQL Editor. Row-level security restricts each row to its signed-in owner.
create table if not exists public.afterdark_user_data (
  user_id uuid primary key references auth.users (id) on delete cascade,
  payload jsonb not null default '{"favs":[],"stats":[],"recent":[],"vibes":[]}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.afterdark_user_data enable row level security;
alter table public.afterdark_user_data force row level security;

revoke all on public.afterdark_user_data from anon;
grant select, insert, update, delete on public.afterdark_user_data to authenticated;

drop policy if exists "Users can read their own gaming hub data" on public.afterdark_user_data;
create policy "Users can read their own gaming hub data"
  on public.afterdark_user_data for select to authenticated
  using ((select auth.uid()) = user_id);

drop policy if exists "Users can insert their own gaming hub data" on public.afterdark_user_data;
create policy "Users can insert their own gaming hub data"
  on public.afterdark_user_data for insert to authenticated
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users can update their own gaming hub data" on public.afterdark_user_data;
create policy "Users can update their own gaming hub data"
  on public.afterdark_user_data for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

drop policy if exists "Users can delete their own gaming hub data" on public.afterdark_user_data;
create policy "Users can delete their own gaming hub data"
  on public.afterdark_user_data for delete to authenticated
  using ((select auth.uid()) = user_id);

-- Security audit log: only Edge Functions using the service-role key may read/write this table.
create table if not exists public.afterdark_login_audit (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users (id) on delete cascade,
  ip_address inet not null,
  logged_at timestamptz not null default now()
);

create index if not exists afterdark_login_audit_logged_at_idx
  on public.afterdark_login_audit (logged_at desc);
create index if not exists afterdark_login_audit_user_id_idx
  on public.afterdark_login_audit (user_id, logged_at desc);

alter table public.afterdark_login_audit enable row level security;
alter table public.afterdark_login_audit force row level security;
revoke all on public.afterdark_login_audit from anon, authenticated;

-- Configure a daily Supabase Cron job to run this cleanup query for strict 30-day retention:
-- delete from public.afterdark_login_audit where logged_at < now() - interval '30 days';
create extension if not exists pg_cron with schema pg_catalog;
select cron.unschedule(jobid) from cron.job where jobname = 'afterdark-login-audit-retention';
select cron.schedule(
  'afterdark-login-audit-retention',
  '17 3 * * *',
  $$delete from public.afterdark_login_audit where logged_at < now() - interval '30 days'$$
);
