import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("SITE_ORIGIN") ?? "https://YOUR-SITE-DOMAIN.example",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Vary": "Origin",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { ...corsHeaders, "Content-Type": "application/json", "Cache-Control": "no-store" },
});

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const authorization = request.headers.get("Authorization") ?? "";
  const token = authorization.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return json({ error: "Authentication required" }, 401);

  const url = Deno.env.get("SUPABASE_URL");
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !anonKey || !serviceKey) return json({ error: "Server is not configured" }, 500);

  const authClient = createClient(url, anonKey, { auth: { persistSession: false } });
  const { data: auth, error: authError } = await authClient.auth.getUser(token);
  if (authError || !auth.user) return json({ error: "Invalid session" }, 401);

  let body: { acknowledged?: boolean };
  try { body = await request.json(); } catch { return json({ error: "Invalid request body" }, 400); }
  if (body.acknowledged !== true) return json({ error: "Audit notice acknowledgment required" }, 400);

  // Only call this endpoint after successful auth and the user has acknowledged the site's IP notice.
  const forwarded = request.headers.get("cf-connecting-ip")
    ?? request.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
  const ipAddress = forwarded?.trim();
  if (!ipAddress || ipAddress.length > 64) return json({ error: "Client IP unavailable" }, 400);

  const adminClient = createClient(url, serviceKey, { auth: { persistSession: false } });
  // Opportunistic expiry cleanup; list endpoint also cleans, and a scheduled job is recommended.
  await adminClient.from("afterdark_login_audit").delete().lt("logged_at", new Date(Date.now() - 30 * 86400000).toISOString());
  const { error } = await adminClient.from("afterdark_login_audit").insert({
    user_id: auth.user.id,
    ip_address: ipAddress,
  });
  if (error) return json({ error: "Could not record login audit event" }, 500);
  return json({ recorded: true });
});
